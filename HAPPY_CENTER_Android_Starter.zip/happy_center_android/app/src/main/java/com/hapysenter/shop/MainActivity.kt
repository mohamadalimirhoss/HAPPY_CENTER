package com.hapysenter.shop

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF20243A)
private val Purple = Color(0xFF6556D9)
private val Pale = Color(0xFFF5F4FB)
private val Muted = Color(0xFF77788A)

data class Product(val name: String, val category: String, val price: String, val description: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HappyCenterApp() }
    }
}

@Composable
fun HappyCenterApp() {
    var selectedTab by remember { mutableStateOf("خانه") }
    var cartCount by remember { mutableIntStateOf(0) }
    var selectedCategory by remember { mutableStateOf("همه") }

    val products = listOf(
        Product("کاندوم کلاسیک", "کاندوم", "قیمت به‌زودی", "محصول بهداشتی دارای مجوز؛ مشخصات کامل پس از تأمین کالا درج می‌شود."),
        Product("ژل روان‌کننده", "مراقبت شخصی", "قیمت به‌زودی", "انتخاب محصول سازگار و دارای مجوز؛ اطلاعات مصرف روی بسته‌بندی."),
        Product("دستمال بهداشتی", "بهداشت فردی", "قیمت به‌زودی", "مناسب استفاده روزمره؛ جزئیات برند و ترکیبات پس از ثبت کالا."),
        Product("بسته مراقبت شخصی", "پک‌ها", "قیمت به‌زودی", "پک انتخابی با بسته‌بندی ساده و محرمانه.")
    )
    val categories = listOf("همه", "کاندوم", "مراقبت شخصی", "بهداشت فردی", "پک‌ها")
    val visible = products.filter { selectedCategory == "همه" || it.category == selectedCategory }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Purple, background = Pale, surface = Color.White,
        onPrimary = Color.White, onBackground = Ink, onSurface = Ink
    )) {
        Scaffold(
            containerColor = Pale,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("خانه", "دسته‌بندی", "سبد خرید", "حساب من").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Text(when(tab) { "خانه" -> "⌂"; "دسته‌بندی" -> "▦"; "سبد خرید" -> "🛒"; else -> "●" }, fontSize = 18.sp) },
                            label = { Text(if (tab == "سبد خرید" && cartCount > 0) "سبد خرید ($cartCount)" else tab) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "سبد خرید" -> CartScreen(cartCount, Modifier.padding(padding))
                "حساب من" -> AccountScreen(Modifier.padding(padding))
                "دسته‌بندی" -> HomeContent(categories, products, visible, selectedCategory,
                    { selectedCategory = it }, { cartCount++ }, Modifier.padding(padding), true)
                else -> HomeContent(categories, products, visible, selectedCategory,
                    { selectedCategory = it }, { cartCount++ }, Modifier.padding(padding), false)
            }
        }
    }
}

@Composable
fun HomeContent(
    categories: List<String>, products: List<Product>, visible: List<Product>,
    selected: String, onCategory: (String) -> Unit, onAdd: () -> Unit,
    modifier: Modifier = Modifier, onlyCategories: Boolean
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("HAPPY CENTER", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("سلام، خوش آمدید", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(46.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
                    Text("H", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(22.dp)).padding(20.dp)) {
                Text("مراقبت، با خیال آسوده", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text("خرید محرمانه محصولات بهداشتی و مراقبت شخصی", color = Color(0xFFE3E0FF), fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Text("بسته‌بندی ساده و حفظ حریم خصوصی", color = Color.White, fontSize = 12.sp)
            }
        }
        item { Text("دسته‌بندی‌ها", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { category ->
                            val active = selected == category
                            Box(
                                Modifier.weight(1f).background(if (active) Purple else Color.White, RoundedCornerShape(14.dp))
                                    .clickable { onCategory(category) }.padding(vertical = 13.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(category, color = if (active) Color.White else Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        if (!onlyCategories) {
            item { Text("پیشنهادهای فروشگاه", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            items(visible) { product ->
                ProductCard(product, onAdd)
            }
        }
        item {
            Text("اطلاعیه: قیمت، موجودی و مشخصات نهایی پس از اتصال پنل مدیریت و ثبت محصولات واقعی نمایش داده می‌شود.",
                color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun ProductCard(product: Product, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(72.dp).background(Pale, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("✦", color = Purple, fontSize = 30.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(product.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(product.category, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(5.dp))
            Text(product.price, color = Purple, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
        Button(onClick = onAdd, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
            Text("افزودن", fontSize = 12.sp)
        }
    }
}

@Composable
fun CartScreen(count: Int, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("سبد خرید", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(if (count == 0) "سبد خرید شما هنوز خالی است." else "$count کالا به سبد خرید اضافه شده است.",
            color = Muted)
        Text("در نسخه بعدی، جزئیات کالا، آدرس، روش ارسال و پرداخت آنلاین تکمیل می‌شود.", fontSize = 13.sp)
    }
}

@Composable
fun AccountScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حساب کاربری", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("ورود با شماره موبایل، سوابق سفارش و پیگیری مرسوله در مرحله بعد اضافه می‌شود.", color = Muted)
        Text("HAPPY CENTER | خرید محرمانه و مطمئن", color = Purple, fontWeight = FontWeight.SemiBold)
    }
}
